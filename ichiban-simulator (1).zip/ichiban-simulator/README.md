# 一番賞線上對戰模擬

Vite + React + Tailwind single-page Ichiban Kuji (一番賞) simulator. Templates are stored in the browser under the `ichiban_templates` localStorage key.

## Run

```bash
npm install
npm run dev
```

Then open http://127.0.0.1:5173 (Vite uses the next free port if 5173 is taken).
