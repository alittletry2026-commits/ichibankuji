import React, { useState, useEffect } from 'react';

// 預設範本資料
const DEFAULT_TEMPLATES = [
  {
    id: 'kuji-1',
    title: '【熱血動漫】最終決戰一番賞',
    cover: '',
    roomCode: '888',
    prizes: [
      { id: 'p1', grade: 'A賞', name: '主角最終型態模型', count: 2, color: 'from-amber-500 to-yellow-600', image: '' },
      { id: 'p2', grade: 'B賞', name: '宿敵覺醒模型', count: 3, color: 'from-purple-500 to-indigo-600', image: '' },
      { id: 'p3', grade: 'C賞', name: '豪華壓克力場景模型', count: 5, color: 'from-blue-500 to-cyan-600', image: '' },
      { id: 'p4', grade: 'D賞', name: '角色金屬徽套組', count: 15, color: 'from-emerald-500 to-teal-600', image: '' },
      { id: 'p5', grade: 'E賞', name: '透明視覺色紙', count: 25, color: 'from-pink-500 to-rose-600', image: '' },
      { id: 'p6', grade: 'F賞', name: 'Q版橡膠吊飾', count: 30, color: 'from-orange-500 to-amber-600', image: '' },
    ],
    lastOne: { grade: 'Last One賞', name: '特別異色版最終模型', color: 'from-red-600 to-black', image: '' }
  }
];

export default function App() {
  const [templates, setTemplates] = useState(() => {
    const saved = localStorage.getItem('ichiban_templates');
    return saved ? JSON.parse(saved) : DEFAULT_TEMPLATES;
  });

  const [activeTemplate, setActiveTemplate] = useState(null);
  const [viewMode, setViewMode] = useState('home'); // 'home' | 'admin' | 'player'
  const [roomInput, setRoomInput] = useState('');
  
  // 抽籤狀態
  const [ticketBox, setTicketBox] = useState([]);
  const [drawnHistory, setDrawnHistory] = useState([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [latestDrawResult, setLatestDrawResult] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    localStorage.setItem('ichiban_templates', JSON.stringify(templates));
  }, [templates]);

  const initBox = (template) => {
    let box = [];
    template.prizes.forEach(p => {
      for (let i = 0; i < p.count; i++) {
        box.push({ ...p, uniqueId: Math.random().toString(36).substr(2, 9) });
      }
    });
    for (let i = box.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [box[i], box[j]] = [box[j], box[i]];
    }
    setTicketBox(box);
    setDrawnHistory([]);
    setLatestDrawResult(null);
  };

  const enterTemplate = (template, mode = 'player') => {
    setActiveTemplate(template);
    initBox(template);
    setViewMode(mode);
  };

  const handleJoinRoom = (e) => {
    e.preventDefault();
    const found = templates.find(t => t.roomCode === roomInput.trim());
    if (found) {
      enterTemplate(found, 'player');
    } else {
      alert('找不到該房間號碼，請確認後再試！');
    }
  };

  const drawTickets = (count) => {
    if (ticketBox.length === 0) return;
    setIsDrawing(true);

    setTimeout(() => {
      const drawCount = Math.min(count, ticketBox.length);
      const drawn = ticketBox.slice(0, drawCount);
      const remaining = ticketBox.slice(drawCount);

      setTicketBox(remaining);
      setDrawnHistory(prev => [...drawn, ...prev]);
      setLatestDrawResult(drawn);
      setIsDrawing(false);
      setShowModal(true);
    }, 600);
  };

  const handleImageUpload = (e, callback) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        callback(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-black">
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setViewMode('home')}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center font-bold text-slate-950 shadow-lg shadow-amber-500/20">
            一番
          </div>
          <span className="font-bold text-lg tracking-wider bg-gradient-to-r from-amber-200 to-yellow-400 bg-clip-text text-transparent">
            一番賞線上對戰模擬
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <form onSubmit={handleJoinRoom} className="flex items-center bg-slate-800 rounded-lg border border-slate-700 overflow-hidden px-2 py-1">
            <span className="text-xs text-slate-400 mr-1">房號:</span>
            <input 
              type="text" 
              maxLength="3"
              placeholder="例: 888" 
              value={roomInput}
              onChange={(e) => setRoomInput(e.target.value)}
              className="bg-transparent text-sm w-16 text-amber-400 font-mono focus:outline-none text-center"
            />
            <button type="submit" className="text-xs bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-2.5 py-1 rounded transition">
              進入
            </button>
          </form>

          {viewMode !== 'home' && (
            <button 
              onClick={() => setViewMode('home')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-sm border border-slate-700 transition"
            >
              返回大廳
            </button>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6">
        {viewMode === 'home' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">精選一番賞看板</h1>
                <p className="text-sm text-slate-400">選擇心儀的一番賞或建立屬於你自己的專屬籤筒！</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              <div 
                onClick={() => {
                  const newTemplate = {
                    id: 'kuji-' + Date.now(),
                    title: '新一番賞主題',
                    cover: '',
                    roomCode: Math.floor(100 + Math.random() * 900).toString(),
                    prizes: [
                      { id: 'p1', grade: 'A賞', name: '大獎模型', count: 2, color: 'from-amber-500 to-yellow-600', image: '' },
                      { id: 'p2', grade: 'B賞', name: '次賞模型', count: 3, color: 'from-purple-500 to-indigo-600', image: '' },
                      { id: 'p3', grade: 'C賞', name: '壓克力立牌', count: 5, color: 'from-blue-500 to-cyan-600', image: '' },
                    ],
                    lastOne: { grade: 'Last One賞', name: '最後賞異色模型', color: 'from-red-600 to-black', image: '' }
                  };
                  setTemplates([...templates, newTemplate]);
                  enterTemplate(newTemplate, 'admin');
                }}
                className="group border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer h-80 transition bg-slate-900/40 hover:bg-slate-900/80"
              >
                <div className="w-14 h-14 rounded-full bg-slate-800 group-hover:bg-amber-500 group-hover:text-slate-950 flex items-center justify-center text-2xl font-bold text-slate-300 transition shadow-md mb-3">
                  +
                </div>
                <span className="font-bold text-slate-200 group-hover:text-amber-400">建立新一番賞</span>
                <span className="text-xs text-slate-500 mt-1">自訂獎項、數量與本地圖片</span>
              </div>

              {templates.map(tmpl => {
                const totalTickets = tmpl.prizes.reduce((sum, p) => sum + p.count, 0);
                return (
                  <div 
                    key={tmpl.id}
                    className="group bg-slate-900 border border-slate-800 hover:border-amber-500/60 rounded-2xl overflow-hidden flex flex-col h-80 shadow-lg transition transform hover:-translate-y-1"
                  >
                    <div className="h-40 bg-slate-800 relative overflow-hidden flex items-center justify-center">
                      {tmpl.cover ? (
                        <img src={tmpl.cover} alt={tmpl.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                      ) : (
                        <div className="text-slate-600 font-bold text-lg">一番賞海報</div>
                      )}
                      <div className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur px-2 py-0.5 rounded-full text-xs font-mono text-amber-400 border border-slate-700">
                        房號: {tmpl.roomCode}
                      </div>
                    </div>

                    <div className="p-3.5 flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="font-bold text-sm text-slate-100 line-clamp-1 group-hover:text-amber-400 transition">{tmpl.title}</h3>
                        <p className="text-xs text-slate-400 mt-1">總籤數: <span className="text-slate-200 font-bold">{totalTickets} 張</span></p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <button 
                          onClick={() => enterTemplate(tmpl, 'player')}
                          className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-1.5 rounded-xl text-xs transition shadow"
                        >
                          進入抽籤
                        </button>
                        <button 
                          onClick={() => enterTemplate(tmpl, 'admin')}
                          className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-1.5 rounded-xl text-xs border border-slate-700 transition"
                        >
                          編輯後台
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {viewMode === 'admin' && activeTemplate && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center pb-6 border-b border-slate-800 gap-4">
              <div>
                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs px-2.5 py-1 rounded-full font-mono">
                  房間號碼: {activeTemplate.roomCode}
                </span>
                <h2 className="text-xl font-bold mt-2">編輯一番賞設定</h2>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={() => enterTemplate(activeTemplate, 'player')}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm transition shadow-lg shadow-amber-500/20"
                >
                  儲存並開始抽籤
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">一番賞標題</label>
                  <input 
                    type="text" 
                    value={activeTemplate.title}
                    onChange={(e) => {
                      const updated = { ...activeTemplate, title: e.target.value };
                      setActiveTemplate(updated);
                      setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">封面海報圖片 (本地上傳)</label>
                  <div className="flex items-center space-x-3">
                    {activeTemplate.cover && (
                      <img src={activeTemplate.cover} alt="Cover" className="w-16 h-16 object-cover rounded-xl border border-slate-700" />
                    )}
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, (base64) => {
                        const updated = { ...activeTemplate, cover: base64 };
                        setActiveTemplate(updated);
                        setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                      })}
                      className="text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-4 rounded-2xl">
                <h3 className="font-bold text-sm text-amber-400 mb-3">Last One 賞（完封獎）設定</h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <input 
                      type="text" 
                      value={activeTemplate.lastOne.grade}
                      onChange={(e) => {
                        const updated = { ...activeTemplate, lastOne: { ...activeTemplate.lastOne, grade: e.target.value } };
                        setActiveTemplate(updated);
                        setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                      }}
                      className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs"
                      placeholder="獎項等級"
                    />
                    <input 
                      type="text" 
                      value={activeTemplate.lastOne.name}
                      onChange={(e) => {
                        const updated = { ...activeTemplate, lastOne: { ...activeTemplate.lastOne, name: e.target.value } };
                        setActiveTemplate(updated);
                        setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                      }}
                      className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs"
                      placeholder="獎品名稱"
                    />
                  </div>
                  <div className="flex items-center space-x-3">
                    {activeTemplate.lastOne.image && (
                      <img src={activeTemplate.lastOne.image} alt="LastOne" className="w-12 h-12 object-cover rounded-lg border border-slate-700" />
                    )}
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, (base64) => {
                        const updated = { ...activeTemplate, lastOne: { ...activeTemplate.lastOne, image: base64 } };
                        setActiveTemplate(updated);
                        setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                      })}
                      className="text-xs text-slate-400 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:bg-slate-800 file:text-slate-200 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-sm">賞品等級與機率配比設定</h3>
                <button 
                  onClick={() => {
                    const newPrizes = [...activeTemplate.prizes, { id: 'p-' + Date.now(), grade: '新賞', name: '新獎品名稱', count: 5, color: 'from-blue-500 to-indigo-600', image: '' }];
                    const updated = { ...activeTemplate, prizes: newPrizes };
                    setActiveTemplate(updated);
                    setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 transition"
                >
                  + 新增一階賞品
                </button>
              </div>

              <div className="space-y-3">
                {activeTemplate.prizes.map((prize, index) => (
                  <div key={prize.id} className="bg-slate-950/40 border border-slate-800/80 p-3 rounded-2xl flex flex-col md:flex-row items-center gap-3">
                    <div className="flex items-center space-x-2 w-full md:w-auto">
                      {prize.image ? (
                        <img src={prize.image} alt={prize.grade} className="w-12 h-12 object-cover rounded-xl border border-slate-700 flex-shrink-0" />
                      ) : (
                        <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center text-xs text-slate-500 flex-shrink-0">無圖</div>
                      )}
                      <input 
                        type="file" 
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, (base64) => {
                          const updatedPrizes = [...activeTemplate.prizes];
                          updatedPrizes[index].image = base64;
                          const updated = { ...activeTemplate, prizes: updatedPrizes };
                          setActiveTemplate(updated);
                          setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                        })}
                        className="text-xs text-slate-400 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-xs file:bg-slate-800 file:text-slate-200 cursor-pointer w-32"
                      />
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 flex-1 w-full">
                      <input 
                        type="text" 
                        value={prize.grade}
                        onChange={(e) => {
                          const updatedPrizes = [...activeTemplate.prizes];
                          updatedPrizes[index].grade = e.target.value;
                          const updated = { ...activeTemplate, prizes: updatedPrizes };
                          setActiveTemplate(updated);
                          setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                        }}
                        className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs font-bold"
                        placeholder="等級 (如 A賞)"
                      />
                      <input 
                        type="text" 
                        value={prize.name}
                        onChange={(e) => {
                          const updatedPrizes = [...activeTemplate.prizes];
                          updatedPrizes[index].name = e.target.value;
                          const updated = { ...activeTemplate, prizes: updatedPrizes };
                          setActiveTemplate(updated);
                          setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                        }}
                        className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs"
                        placeholder="獎品名稱"
                      />
                      <div className="flex items-center space-x-1 col-span-2 md:col-span-1">
                        <span className="text-xs text-slate-400">數量:</span>
                        <input 
                          type="number" 
                          value={prize.count}
                          onChange={(e) => {
                            const updatedPrizes = [...activeTemplate.prizes];
                            updatedPrizes[index].count = parseInt(e.target.value) || 0;
                            const updated = { ...activeTemplate, prizes: updatedPrizes };
                            setActiveTemplate(updated);
                            setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                          }}
                          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs w-full text-center"
                        />
                      </div>
                    </div>

                    <button 
                      onClick={() => {
                        const updatedPrizes = activeTemplate.prizes.filter((_, i) => i !== index);
                        const updated = { ...activeTemplate, prizes: updatedPrizes };
                        setActiveTemplate(updated);
                        setTemplates(templates.map(t => t.id === updated.id ? updated : t));
                      }}
                      className="text-rose-400 hover:text-rose-300 text-xs px-2 py-1 transition"
                    >
                      刪除
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {viewMode === 'player' && activeTemplate && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl text-center">
                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs px-3 py-1 rounded-full font-mono">
                  房號: {activeTemplate.roomCode}
                </span>
                <h2 className="text-lg font-bold mt-3">{activeTemplate.title}</h2>

                <div className="my-6 bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <div className="text-3xl font-black text-amber-400 font-mono">
                    {ticketBox.length} <span className="text-sm font-normal text-slate-400">/ 總籤數</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-3">
                    <div 
                      className="bg-gradient-to-r from-amber-500 to-yellow-300 h-full transition-all duration-500"
                      style={{ width: `${(ticketBox.length / activeTemplate.prizes.reduce((s, p) => s + p.count, 0)) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <div className="space-y-3">
                  <button 
                    onClick={() => drawTickets(1)}
                    disabled={isDrawing || ticketBox.length === 0}
                    className="w-full bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black py-3.5 rounded-2xl shadow-lg shadow-amber-500/20 transition disabled:opacity-50"
                  >
                    {isDrawing ? '抽籤中...' : '單抽 (1張)'}
                  </button>

                  <button 
                    onClick={() => drawTickets(10)}
                    disabled={isDrawing || ticketBox.length === 0}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-amber-400 border border-amber-500/30 font-bold py-3 rounded-2xl transition disabled:opacity-50"
                  >
                    十連抽 (10張)
                  </button>

                  <button 
                    onClick={() => initBox(activeTemplate)}
                    className="w-full text-xs text-slate-500 hover:text-slate-300 py-1 transition"
                  >
                    重置籤筒 (重新洗牌)
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
                <h3 className="font-bold text-sm mb-4">一番賞即時殘量大樹</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {activeTemplate.prizes.map(prize => {
                    const remaining = ticketBox.filter(t => t.grade === prize.grade).length;
                    return (
                      <div key={prize.id} className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-2xl flex items-center space-x-3">
                        {prize.image ? (
                          <img src={prize.image} alt={prize.grade} className="w-12 h-12 object-cover rounded-xl border border-slate-700" />
                        ) : (
                          <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center text-xs text-slate-600">無圖</div>
                        )}
                        <div>
                          <div className="font-bold text-xs text-amber-400">{prize.grade}</div>
                          <div className="text-xs text-slate-300 line-clamp-1">{prize.name}</div>
                          <div className="text-xs font-mono text-slate-400 mt-1">剩餘: <strong className="text-slate-100">{remaining}</strong> 張</div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-4 bg-gradient-to-r from-red-950/40 to-slate-950 border border-red-900/40 p-3.5 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {activeTemplate.lastOne.image && (
                      <img src={activeTemplate.lastOne.image} alt="LastOne" className="w-12 h-12 object-cover rounded-xl border border-red-700/50" />
                    )}
                    <div>
                      <div className="font-bold text-xs text-red-400">{activeTemplate.lastOne.grade}</div>
                      <div className="text-xs text-slate-300">{activeTemplate.lastOne.name}</div>
                    </div>
                  </div>
                  <div className="text-xs font-mono text-red-300 bg-red-950/60 px-2.5 py-1 rounded-xl border border-red-900/60">
                    {ticketBox.length === 0 ? '🎉 已解鎖!' : `還需 ${ticketBox.length} 張`}
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
                <h3 className="font-bold text-sm mb-4">歷史抽獎紀錄</h3>
                {drawnHistory.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 text-xs">尚無抽獎紀錄，快來試試手氣吧！</div>
                ) : (
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2.5 max-h-64 overflow-y-auto pr-1">
                    {drawnHistory.map((item, idx) => (
                      <div key={idx} className="bg-slate-950 border border-slate-800 p-2.5 rounded-xl text-center flex flex-col items-center">
                        <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full mb-1">{item.grade}</span>
                        {item.image ? (
                          <img src={item.image} alt="" className="w-10 h-10 object-cover rounded-lg my-1" />
                        ) : null}
                        <span className="text-[11px] text-slate-300 line-clamp-1">{item.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {showModal && latestDrawResult && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-center animate-in fade-in zoom-in duration-200">
            <h3 className="text-lg font-bold text-amber-400 mb-4">🎉 恭喜獲得以下獎項！</h3>
            
            <div className={`grid gap-3 my-4 ${latestDrawResult.length > 1 ? 'grid-cols-2 sm:grid-cols-3 max-h-96 overflow-y-auto pr-1' : 'grid-cols-1'}`}>
              {latestDrawResult.map((res, i) => (
                <div key={i} className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex flex-col items-center">
                  <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full mb-2">{res.grade}</span>
                  {res.image ? (
                    <img src={res.image} alt="" className="w-20 h-20 object-cover rounded-xl my-2 border border-slate-700" />
                  ) : (
                    <div className="w-20 h-20 bg-slate-900 rounded-xl flex items-center justify-center text-xs text-slate-600 my-2">無獎品圖片</div>
                  )}
                  <span className="text-xs text-slate-200 font-medium line-clamp-2">{res.name}</span>
                </div>
              ))}
            </div>

            {ticketBox.length === 0 && (
              <div className="my-3 bg-red-950/80 border border-red-800 text-red-300 p-3 rounded-2xl text-xs font-bold animate-bounce">
                🔥 恭喜抽完最後一張！額外獲得 Last One 賞：{activeTemplate.lastOne.name}！
              </div>
            )}

            <button 
              onClick={() => setShowModal(false)}
              className="mt-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-sm transition shadow-lg"
            >
              確定 / 繼續抽
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
